import { main } from './services';

main().catch(console.error);
