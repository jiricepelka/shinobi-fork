pub const PREFIX_CHAIN_DB: &[u8] = b"chaindb";
pub const CONFIG_KEY: &[u8] = b"config";
