# Bitcoin Header Chain

Copied some functions from [Murmel](https://github.com/rust-bitcoin/murmel) and optimized them for Secret Contract.
