# PROTO BUILD


`proto/cosmos` is from https://github.com/cosmos/cosmos-sdk/tree/v0.45.4
`proto/tendermint` is from https://github.com/tendermint/tendermint/tree/v0.34.19/proto
to see docs, `cargo doc` and `open target/doc/sfps_lib/index.html`